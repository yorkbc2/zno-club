<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Topic;
use App\TopicCategory;

class ForumController extends Controller
{
    public function index () {
    	$topics = Topic::where('status', '=', 1)->orderBy('id', 'desc')->paginate(10);

    	return view('front.forum.index', ['topics' => $topics]);
    }

    public function topic_add_get () {
    	$categories = TopicCategory::get();
    	return view('front.forum.add-topic' , ['categories' => $categories]);
    }

    public function topic_add_post (Request $req) {
    	$title = $req->t_title;
    	$content = $req->t_content;
    	$category = $req->t_category;

    	$author = _GU();

    	$data = [
    		'title' => $title,
    		'content' => $content,
    		'category_id' => intval($category),
    		'views' => 0,
    		'comments_able' => 1,
    		'status' => 1,
    		'author_id' => $author->id,
    		'author_name' => $author->name,
    		'author_avatar' => $author->avatar,
    		'created_at' => date('Y-m-d H:i')
    	];

    	$tid = Topic::insertGetId($data);

    	return rdph('/forum/topic/'.$tid);

    }

    public function topic ($topicId) {
    	return view('front.forum.topic');
    }

    public function category ($categoryUrl) {
    	$category = TopicCategory::where('alt_url', '=', $categoryUrl)->orWhere('id', '=', $categoryUrl)->first();

    	$topics=[];

    	if($categoryUrl == "all") {
    		$topics = Topic::where('status', '=', 1)->paginate(10);
    	}
    	else {
	    	$topics = Topic::where([
	    		['category_id', '=', $category->id],
	    		['status', '=', 1]
	    	])->paginate(10);
    	}

    	return view('front.forum.category', ['current_cat' => $categoryUrl, 'topics' => $topics]);
    }
}
