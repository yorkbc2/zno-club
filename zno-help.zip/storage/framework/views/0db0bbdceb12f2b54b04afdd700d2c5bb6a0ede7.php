<?php $__env->startSection('imported_content'); ?>

	<div class="main-container">
		<div class="posts-container">
			
		</div>
		<div class="side-container">
			
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>