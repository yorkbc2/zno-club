<?php $__env->startSection('imported_content'); ?>

	<div class="container">
		<div class="row">
			<div class="col-md-6 col-md-offset-3">
				<div class="panel panel-default">
					<div class="panel-body">
						<h1>
							Добавити категорію:
						</h1>
						<form class='form-field' action="/admin/forum/add-category" method="post">
							<?php echo e(csrf_field()); ?>

							<input type="hidden" name="red_url" value="/admin/forum/category">
							<div class="form-group">
								<input type="text" placeholder="Title" class='form-control' name='cat_title'>
							</div>
							<div class="form-group">
								<input type="text" placeholder="Alternative link" class='form-control' name='cat_alt_link'>
							</div>
							<div class="form-group">
								<button type="submit" class='btn btn-default'>
									Додати +
								</button>
							</div>
						</form>
						<table class="table table-hover table-bordered">
							<thead>
								<tr>
									<th>ID, #</th>
									<th>Name:</th>
									<th>Url: </th>
								</tr>
							</thead>
							<tbody>
								<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

								<tr>
									<td><?php echo e($cat->id); ?></td>
									<td><?php echo e($cat->title); ?></td>
									<td><?php echo e($cat->alt_url); ?></td>
								</tr>

								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>