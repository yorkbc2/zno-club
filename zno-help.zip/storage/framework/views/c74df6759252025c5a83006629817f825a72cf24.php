<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>
		<?php if(isset($title)): ?>
			<?php echo e($title); ?> :: ЗНО-Клуб
		<?php else: ?>
			ЗНО-Клуб
		<?php endif; ?>
	</title>

	<link href="https://fonts.googleapis.com/css?family=Russo+One|Roboto+Slab" rel="stylesheet">
	<link rel="stylesheet" href='<?php echo e(pl("/css/styles.css")); ?>'>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
	<div class="wrapper">
	
		

		<?php echo $__env->make('layouts.components.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

		

		<div class="app-wrapper" id='app'>
			<?php echo $__env->yieldContent('imported_content'); ?>
		</div>

		

	</div>



	<script src="<?php echo e(pl('/js/app.js')); ?>"></script>
	<script src="/vendor/unisharp/laravel-ckeditor/ckeditor.js"></script>
    <script>
        $(document).ready(function () {
        	CKEDITOR.replace( 't_content_area' );
        })
    </script>
	
</body>
</html>