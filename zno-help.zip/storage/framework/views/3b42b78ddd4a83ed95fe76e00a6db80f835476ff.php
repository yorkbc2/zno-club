<?php $__env->startSection('imported_content'); ?>

	<div class="main-container">
		<div class="content-container">
			<div class="categories-list">
				
				<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

				<div class="category-item">
					
					<h2>
						<a href="<?php echo e(pl("/info/".$cat->alt_link)); ?>">
							<?php echo e($cat->title); ?>

						</a>
					</h2>

				</div>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

			</div>			
		</div>
		<div class="side-container">
			<?php echo $__env->make('layouts.components.aside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', ['title' => "Інформація"], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>