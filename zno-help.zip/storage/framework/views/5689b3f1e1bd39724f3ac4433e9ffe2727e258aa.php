<?php $__env->startSection('imported_content'); ?>

	<div class="main-container">
		<div class='content-container'>
			<h1>
				Сторінка у розробці!
			</h1>
		</div>
		<div class="side-container">
			<?php echo $__env->make('layouts.components.aside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', ['title' => "В розробці"], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>