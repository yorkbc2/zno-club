<?php $__env->startSection('imported_content'); ?>

	<div class="main-container">
		<?php echo $__env->yieldContent('action'); ?>
		<div class="content-container">
		
			
			<div class="panel columns">
				
				<div class="column profile-aside">
						
					<div class="profile-image">
						<img src="<?php echo e(pl($profile->avatar)); ?>" alt="Портрет не знайдено!">
						<a href='?action=change_avatar' class='profile-image--change icon-button'>
							<i class="fa fa-pencil"></i>
						</a>
					</div>

					<div class="profile-social">
						<div class="profile-social--add">
							<a href='?action=add_social' class="read-more--button">
								Додати соц. мережі
							</a>
						</div>
						<div class="profile-social--list">
							<?php echo getSocialLinks(_GU()->id); ?>

						</div>
					</div>

				</div>

				<div class="column" style='flex: 3;'>
					<h2 class='line-header'>
						<?php echo e($profile->name); ?>

					</h2>
					<p>
						Поштова скринька: <?php echo e($profile->email); ?>

					</p>
					<p>
						Комментарів: <?php echo e(count(getComments($profile->id))); ?>

					</p>
					<p>
						Топіків: 0
					</p>
					<p>
						Репутація: 0
					</p>
				</div>

			</div>


		</div>
		<div class="side-container">
			<?php echo $__env->make('layouts.components.aside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', ['title' => $profile->name], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>