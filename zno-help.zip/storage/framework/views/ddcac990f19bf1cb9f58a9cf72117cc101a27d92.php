<?php $__env->startSection('imported_content'); ?>

	<div class="container">
		<div class="row">
			<div class="col-md-6 col-md-offset-3">
				<div class="panel panel-default">
					<div class="panel-body">
						<h1>
							Керування комментарями:
						</h1>
						<form action="/admin/remove-comments" method="post">
							<?php echo e(csrf_field()); ?>

							<input type="hidden" name="red_url" value="/admin/profile/commentaries">
						<?php $__currentLoopData = getAllCommentaries(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

						<div class='commentary'>
						<div class='c-aside'>
							<input type="checkbox" value="<?php echo e($comment->id); ?>" name="comment_ids[]">
							<div class="c-aside--image">
								<img src="<?php echo e(pl($comment->author_avatar)); ?>" alt="<?php echo e($comment->author_name); ?>">
							</div>
						</div>
						<div class="c-inside">
							<?php if(checkUser()): ?>
								<?php if($comment->author_id == _GU()->id): ?>
								<div class="c-remove">
									<form action="<?php echo e(pl('/post/remove-comment')); ?>" method="post">
										<?php echo e(csrf_field()); ?>

										<input type="hidden" name='commentary_id' value="<?php echo e($comment->id); ?>">
										<input type="hidden" name='author_id' value="<?php echo e(_GU()->id); ?>">
										<input type="hidden" name='redirect_url' value="<?php echo e(pl('/post/'.$post->alt_link)); ?>">
										<button type='submit'>
											<i class="fa fa-trash"></i>
										</button>
									</form>
								</div>
								<?php endif; ?>
							<?php endif; ?>
							<div class="c-inside--content">
								<h3><a href='<?php echo e(pl("/profile/".$comment->author_id)); ?>'><?php echo e($comment->author_name); ?></a></h3>
								<p>
									<?php echo e($comment->content); ?>

								</p>
							</div>
						</div>
					</div>

						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

						<div>
							<button class='btn btn-danger' type='submit'>
								Видалити обрані
							</button>
						</div>
					</form>
					</div>
				</div>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>