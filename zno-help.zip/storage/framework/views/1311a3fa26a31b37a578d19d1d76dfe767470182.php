<?php $__env->startSection('action'); ?>

	<div class="modal-window">
		<div class="modal-block">
			<div class="modal-header">
				<h2 class='modal-heading'>
					Додати соц. мережі
				</h2>
				<div class="modal-close">
					<a href='<?php echo e(pl('/profile')); ?>'>
						&times;
					</a>
				</div>
			</div>
			<div class="modal-body">
				<div class="add-socials">
					<form method="post" class='form-by-groups' action="<?php echo e(pl('/profile/add-social')); ?>">
						<?php echo e(csrf_field()); ?>

						<?php $links = getSocialLinksRaw(_GU()->id) ?>
						<div>
							<i class="fa fa-facebook"></i>
							<input type="text" placeholder='facebook.com/...' value="<?php echo e(checkSocialLink($links, "facebook")); ?>" name='links[facebook]'>
						</div>
						<div>
							<i class="fa fa-twitter"></i>
							<input type="text" placeholder='twitter.com/...' value="<?php echo e(checkSocialLink($links, "twitter")); ?>" name='links[twitter]'> 
						</div>
						<div>
							<i class="fa fa-instagram"></i>
							<input type="text" placeholder='instagram.com/...' value="<?php echo e(checkSocialLink($links, "instagram")); ?>" name='links[instagram]'>
						</div>
						<div>
							<i class="fa fa-vk"></i>
							<input type="text" placeholder='vk.com/...' value="<?php echo e(checkSocialLink($links, "vk")); ?>" name='links[vk]'>
						</div>
						<div>
							<i class="fa fa-github"></i>
							<input type="text" placeholder='github.com/...' value="<?php echo e(checkSocialLink($links, "github")); ?>" name='links[github]'>
						</div>
						<div></div>
						<div>
							<button type='submit' class='read-more--button'>
								Додати
							</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.profile.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>