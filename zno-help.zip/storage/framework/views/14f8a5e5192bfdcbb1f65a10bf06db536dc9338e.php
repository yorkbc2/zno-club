<nav class='main-nav'>
    <ul class='nav-list left'>
    	<li class='nav-brand'>
    		<a href='<?php echo e(pl('/')); ?>'>
    			ЗНО-Клуб
    		</a>
    	</li>
    	<li>
    		<a href='<?php echo e(pl('/posts')); ?>'>
    			Статті
    		</a>
    	</li>
    	<li>
    		<a href='<?php echo e(pl('/forum')); ?>'>
    			Форум
    		</a>
    	</li>
    	<li>
    		<a href='<?php echo e(pl('/info')); ?>'>
    			Інформація
    		</a>
    	</li>
    </ul>
    <ul class='nav-list right'>
        
            <?php if(checkUser()): ?>
            <li class='nav-profile--droptarget'>
                <a href="#">
                    <div class='nav-profile--avatar'>
                        <img src="<?php echo e(pl(_GU()->avatar)); ?>" alt="_" title="<?php echo e(_GU()->name); ?>">
                        
                    </div>
                </a>
                <i class="caret"></i>
                <ul class="nav-profile--dropdown">
                    <li>
                        <a href="<?php echo e(pl("/profile")); ?>">
                            Профіль
                        </a>
                        
                    </li>
                    <li>    
                        <a href="<?php echo e(pl("/profile/settings")); ?>">
                            Налаштування
                        </a>
                    </li>
                    <li>   
                        <a href="<?php echo e(pl("/logout")); ?>">
                            Вийти
                        </a>
                    </li>
                </ul>
            </li>
            <?php else: ?>
            <li>
                <a href='<?php echo e(pl("/signup")); ?>'>
                    Вхід та реєстрація
                </a>
            </li>
            <?php endif; ?>
    </ul>
</nav>