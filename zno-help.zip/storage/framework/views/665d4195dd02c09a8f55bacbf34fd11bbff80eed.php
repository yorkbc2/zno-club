<?php $__env->startSection('imported_content'); ?>

	<div class="main-container">
		<div class="content-container">
			<div class="panel">
				<div class="PageInfo__image">
					<img src="<?php echo e(pl($page->main_image)); ?>" alt="Картинку не знайдено! :(" title="<?php echo e($page->title); ?>">
					<div class="PageInfo__mask">
						<h2>
							<?php echo e($page->title); ?>

						</h2>
						<h4>
							<i class="fa fa-calendar"></i>
							<?php echo e($page->created_at); ?> |
							<i class="fa fa-eye"></i>
							<?php echo e($page->views); ?>

						</h4>
					</div>
				</div>

				<div class="PageInfo__content">
					<?php echo $page->content; ?>

				</div>
			</div>		
		</div>
		<div class="side-container">
			<?php echo $__env->make('layouts.components.aside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>