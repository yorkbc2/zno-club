<?php $__env->startSection('imported_content'); ?>

	<div class="main-container">
		<div class="content-container">
			<div class="panel">
				<form action="/forum/add-topic" method='post' class="form">
					<?php echo e(csrf_field()); ?>

					<div>
						<label for="t-title">Назва топіку:</label>
						<input type="text" id="t-title" name='t_title' placeholder="Введіть назву топіку" required>
					</div>
					<div>
						<textarea name="t_content" id="t_content_area" required maxlength="3000" placeholder="Ваш топік тут..."></textarea>
					</div>
					<div>
						<label for="t-category-id">
							Категорія топіку:
						</label>
						<select id='t-category-id' name="t_category">
							<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($cat->id); ?>"><?php echo e($cat->title); ?></option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</div>
					<div>
						<button type="submit" class='button green'>
							Додати +
						</button>
					</div>
				</form>
			</div>		
		</div>
		<div class="side-container">
			<?php echo $__env->make('layouts.components.aside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', ['title' => "Додати топік"], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>