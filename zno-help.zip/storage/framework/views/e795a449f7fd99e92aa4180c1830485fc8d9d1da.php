<?php $__env->startSection('imported_content'); ?>

	<div class="main-container">
		<div class="content-container">
			<div class="panel">
				<div>
					<h2 class='inline-block'>Форум: </h2> 
					<?php if(checkUser()): ?>
					<a class='button green' href="/forum/add-topic">
						Додати топік
					</a>
					<?php endif; ?>

				</div>
				<div>
					<p class='muted'>Тут Ви можете поділитися своїми думками, обсудити їх з іншими користувачами та прочитати інші топіки.</p>
					<p>
						<select style='width: 240px' onchange="document.location.href='/forum/category/'+$(this).val(); return true;">
							<option value="all" selected>
								Всі топіки
							</option>
							<?php $__currentLoopData = getTopicCategories(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
							<option value="<?php echo e($cat->alt_url); ?>">
								<?php echo e($cat->title); ?>

							</option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</select>
					</p>
				</div>
			</div>	
			<hr style='background-color:  transparent; color: transparent;'>

			<div class="panel">
				<?php if(count($topics) > 0): ?> 
				<div class='topic-list'>
				<?php $__currentLoopData = $topics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $topic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php $current_category = getCategoryById($topic->id); ?>
					<div class="topic">
						<div class="topic-info">
							<a href="<?php echo e(pl('/profile/'.$topic->author_id)); ?>">
								<div class='topic-avatar'><img src="<?php echo e(pl($topic->author_avatar)); ?>" alt="Портрет не знайдено" title="<?php echo e($topic->author_name); ?>"></div>
								<?php echo e($topic->author_name); ?>

							</a>
						</div>
						<div class="topic-content">
							<a href="<?php echo e(pl('/forum/topic/'.$topic->id)); ?>"><h2><?php echo e($topic->title); ?></h2></a>
							<div class="topic-comments">
								0
							</div>
						</div>
						<div class="topic-footer">
							<span class="category">
								<a href="<?php echo e(pl("/forum/category/".$current_category->alt_url)); ?>"><?php echo e($current_category->title); ?></a>
							</span>
							<span class="date">
								<?php echo e($topic->created_at); ?>

							</span>
						</div>
					</div>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<div class="center">
					<?php echo e($topics->links()); ?>

				</div>
				<?php endif; ?>
			</div>		
		</div>
	</div>
		<div class="side-container">
			<?php echo $__env->make('layouts.components.aside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', ['title' => "Форум"], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>