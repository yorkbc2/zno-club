<?php $__env->startSection('imported_content'); ?>

	<div class="main-container">
		<div class="content-container">
			

		<div class="columns">
			
			<div class="panel column">
				<h2 class='line-header'>Реєстрація:</h2>
				<?php if(isset($error_message)): ?>
					<div class="error-message">
						<?php echo e($error_message); ?>

					</div>
				<?php endif; ?>
				<form class='form' action="<?php echo e(pl('/register')); ?>" method='post'>
					<?php echo e(csrf_field()); ?>

					<div>
						<label for="u-name">
							Ваше ім'я:
						</label>
						<input type="text" name='u_name' placeholder='Введіть Ваше ім`я...' required id='u-name' />
					</div>
					<div>
						<label for="u-email">
							Ваша поштова скринька:
						</label>
						<input type="email" name="u_email" placeholder="Введіть Вашу поштову скриньку" required id='u-email' />
					</div>
					<div>
						<label for="u-password">
							Ваш пароль:
						</label>
						<input type="password" name="u_password" placeholder='Придумайте важкий пароль' required id='u-password' />
					</div>
					<div>
						<label for="u-r-password">
							Повторіть Ваш пароль:
						</label>
						<input type="password" name="u_r_password" placeholder='Повторіть Ваш пароль' required id='u-r-password' />
					</div>
					<div>
						<button class='read-more--button' type='submit'>
							Зареєструватися
						</button>
					</div>
				</form>	
			</div>

			<div class="panel column">
				<h2 class="line-header">
					Вхід:
				</h2>
				<form action="<?php echo e(pl('/login')); ?>" method='post' class="form">
					<?php echo e(csrf_field()); ?>

					<div>
						<label for="u-email">Ваша поштова скринька:</label>
						<input type="email" placeholder="Введіть вашу поштову скриньку" required name="u_email" id="u-email">
					</div>
					<div>
						<label for="u-password">Ваш пароль:</label>
						<input type="password"
							placeholder="Введіть Ваш пароль"
							required
							name='u_password'
							id="u-password">
					</div>
					<div>
						<button class="read-more--button" type='submit'>
							Увійти
						</button>
					</div>
				</form>
			</div>

		</div>


		</div>
		<div class="side-container">
			<?php echo $__env->make('layouts.components.aside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', ['title' => "Вхід та реєстрація"], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>