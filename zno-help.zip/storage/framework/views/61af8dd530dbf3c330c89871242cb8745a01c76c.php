<div class="aside-posts">
	
	<h3>
		Найпопулярніші статті:
	</h3>

	<ol>
		<?php $__currentLoopData = get_popular_posts(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

		<li>
			<a <?php if($post->alt_link): ?>
					href='<?php echo e(pl("/post/".$post->alt_link)); ?>'
				<?php else: ?>
					href='<?php echo e(pl("/post/".$post->id)); ?>'
				<?php endif; ?>>
				<?php echo e($post->title); ?> <i class="fa fa-eye"></i> <?php echo e($post->views); ?>

			</a>
		</li>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ol>

</div>

<div class="aside-pbc">
	<h3>
		Найбільше комментарів:
	</h3>

	<ul class="pbc-list">
	<?php $__currentLoopData = getTopUsersByComments(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

	<li>
		<div class="pbc-image">
			<img title="<?php echo e($item["name"]); ?>" src="<?php echo e(pl($item['avatar'])); ?>" alt="<?php echo e($item['name']); ?>">
		</div>
		<div class="pbc-content">
				<a href="<?php echo e(pl('/profile/'.$item['id'])); ?>"><?php echo e($item["name"]); ?></a> - <?php echo e($item["count"]); ?>

		</div>
	</li>
		

	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</ul>
</div>