<?php $__env->startSection('imported_content'); ?>

	<div class="main-container">
		<div class="posts-container">
			<div class="post-list">
			<?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

				<div class="post-item">

				<div class="post-item--image">
					<img src="<?php echo e(pl($post->main_image)); ?>" alt="На жаль, картинку не вдалося зайнти!" title='<?php echo e($post->title); ?>'>
				</div>
					
				<div class="post-item--content">
					<a <?php if($post->alt_link): ?>
						href=<?php echo e(pl('/post/'.$post->alt_link)); ?>

					<?php else: ?>
						href='<?php echo e("/post/".$post->id); ?>'
					<?php endif; ?>>
						<h2>
							<?php echo e($post->title); ?>

						</h2>
					</a>
						<p>
							<?php echo strip_tags(\Illuminate\Support\Str::words($post->content, 15, '...')); ?>

						</p>
						<p>
							<a <?php if($post->alt_link): ?>
								href='<?php echo e(pl("/post/".$post->alt_link)); ?>'
							<?php else: ?>
								href='<?php echo e(pl("/post/".$post->id)); ?>'
							<?php endif; ?> class='read-more--button'>Читати далі</a>
						</p>
				</div>

				</div>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

				
			</div>

			<div class="center">
				<?php echo e($posts->links()); ?>

			</div>

		</div>
		<div class="side-container">
			<?php echo $__env->make('layouts.components.aside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', ['title' => "Всі статті"], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>