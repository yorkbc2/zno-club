<?php $__env->startSection('imported_content'); ?>

	<div class="main-container">
		<?php echo $__env->yieldContent('action'); ?>
		<div class="content-container">
		
			
			<div class="panel columns">
				
				<div class="column profile-aside">
						
					<div class="profile-image">
						<img src="<?php echo e(pl($profile->avatar)); ?>" alt="Портрет не знайдено!" titlte="<?php echo e($profile->name); ?>">
					</div>

					<div class="profile-social">
						<div class="profile-social--list">
							<?php echo getSocialLinks($profile->id); ?>

						</div>
					</div>

				</div>

				<div class="column" style='flex: 3;'>
					<h2 class='line-header'>
						<?php echo e($profile->name); ?>

					</h2>
					<p>
						Комментарів: <?php echo e(count(getComments($profile->id))); ?>

					</p>
					<p>
						Топіків: 0
					</p>
					<p>
						Репутація: 0
					</p>
				</div>

			</div>


		</div>
		<div class="side-container">
			<?php echo $__env->make('layouts.components.aside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', ['title' => $profile->name], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>