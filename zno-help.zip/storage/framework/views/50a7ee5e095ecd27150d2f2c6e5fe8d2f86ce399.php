<?php $__env->startSection('imported_content'); ?>

	<div class="main-container">
		<div class="content-container">
			<div class="post-page">
				
				<div class="post-page--image">
					<img src="<?php echo e(pl($post->main_image)); ?>" alt="На жаль, картинку не знайдено!" title="<?php echo e($post->title); ?>">
				</div>

				<div class="post-page--header">
					<h1><?php echo e($post->title); ?></h1>
				</div>

				<div class="post-page--info">
					<i class="fa fa-calendar"></i> <?php echo e($post->created_at); ?> | <i class="fa fa-eye"></i> <?php echo e($post->views); ?>

				</div>

				<div class="little-divider"></div>

				<div class="post-page--content">
					<?php echo $post->content; ?>

				</div>

				<div class="little-divider"></div>

				<?php if(checkUser()): ?> 
					<comment-post prefix="<?php echo e(pl()); ?>" url='<?php echo e(pl('/add-comment')); ?>' token="<?php echo e(csrf_token()); ?>" postid="<?php echo e($post->id); ?>"></comment-post>
				<?php else: ?>
					<div class="alert-info">
						<p class="icon">
							<i class="fa fa-check"></i>
						</p>
						<p>
							На жаль, Ви не можете коментувати, так як не увійшли до Вашого аккаунту. Будь ласка, <a href="<?php echo e(pl('/signup')); ?>">Увійдіть або Зареєструйтесь на сайті!</a>
						</p>
					</div>
				<?php endif; ?>

				<div class="post-comments">
					<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<div class='commentary'>
						<div class='c-aside'>
							<div class="c-aside--image">
								<img src="<?php echo e(pl($comm->author_avatar)); ?>" alt="<?php echo e($comm->author_name); ?>">
							</div>
						</div>
						<div class="c-inside">
							<?php if(checkUser()): ?>
								<?php if($comm->author_id == _GU()->id): ?>
								<div class="c-remove">
									<form action="<?php echo e(pl('/post/remove-comment')); ?>" method="post">
										<?php echo e(csrf_field()); ?>

										<input type="hidden" name='commentary_id' value="<?php echo e($comm->id); ?>">
										<input type="hidden" name='author_id' value="<?php echo e(_GU()->id); ?>">
										<input type="hidden" name='redirect_url' value="<?php echo e(pl('/post/'.$post->alt_link)); ?>">
										<button type='submit'>
											<i class="fa fa-trash"></i>
										</button>
									</form>
								</div>
								<?php endif; ?>
							<?php endif; ?>
							<div class="c-inside--content">
								<h3><a href='<?php echo e(pl("/profile/".$comm->author_id)); ?>'><?php echo e($comm->author_name); ?></a></h3>
								<p>
									<?php echo e($comm->content); ?>

								</p>
							</div>
						</div>
					</div>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>

			</div>
		</div>
		<div class="side-container">
			<?php echo $__env->make('layouts.components.aside', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', ['title' => $post->title], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>