@extends('admin.layout')

@section('imported_content')

	<div class="container">
		<div class="row">
			<div class="col-md-6 col-md-offset-3">
				<div class="panel panel-default">
					<div class="panel-body">
						<h1>
							HEllooo
						</h1>
					</div>
				</div>
			</div>
		</div>
	</div>

@endsection