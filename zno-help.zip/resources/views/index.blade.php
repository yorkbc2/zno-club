@extends('layouts.main')

@section('imported_content')

	<div class="main-container">
		<div class="posts-container">
			
		</div>
		<div class="side-container">
			
		</div>
	</div>

@endsection