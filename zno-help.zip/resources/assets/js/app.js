import './bootstrap.js'
import Vue from 'vue'

import VueResource from 'vue-resource'

import CommentComponent from "./components/CommentComponent.vue"

Vue.use(VueResource);

Vue.component("comment-post", CommentComponent)


const app = new Vue({
    el: '#app'
});


